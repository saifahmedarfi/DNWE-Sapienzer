Introduction

In today's quickly evolving research landscape, label noise is crucial for the reliability of supervised learning. Moreover, modern datasets frequently contain between 8% and 38% mislabelled instances [1], [2]. Existing methods leverage many heuristics that may fail when the noise is structured. These approaches examine the complex relationships between features and labels without a principled account of uncertainty.

We propose a deterministic filtering framework that achieves robust performance across five benchmarks in this paper. The framework uses a small ensemble of linear models, which are trained on disjoint folds of the data. We show that the method lowers the error rate from 14.2% to 9.7% on CIFAR-10N while needing only 3 GPU-hours. The method doesn't need clean validation labels. That said, it can't recover labels that are methodically flipped by annotators.

## Related Work

A broad range of studies have examined noisy labels. For instance, Co-teaching trains two networks that select small-loss samples for each other [3]. By contrast, confident learning estimates the joint distribution of noisy and true labels [4]. These methods can pinpoint a significant fraction of errors, but they depend on well-calibrated probabilities. Consequently, their performance degrades when the model is overconfident.

## Conclusion

The proposed framework provides a seamless and transparent alternative to black-box filtering. Future work will study whether the approach generalises to text and audio datasets with more than 100 classes.
