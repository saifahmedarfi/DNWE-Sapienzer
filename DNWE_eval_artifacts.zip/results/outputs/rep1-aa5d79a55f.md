# Quarterly Infrastructure Report

## Summary

In today's fast-paced environment, the platform team significantly improved availability to 99.95% this quarter. Moreover, the migration to the new cluster was completed two weeks ahead of schedule.

The team used automated canary releases, which reduced failed deployments from 14 to 3.

## Key changes

- The monitoring stack now uses OpenTelemetry for all services.

- On-call rotations were reduced from weekly to biweekly.

- Backups are confirmed every 24 hours.

| Metric | Q2 | Q3 |
| --- | --- | --- |
| Availability | 99.80% | 99.95% |
| Failed deploys | 14 | 3 |

The budget for Q4 remains unchanged at $120,000, and no new hires are planned.
