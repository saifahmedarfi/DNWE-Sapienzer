# A Note on Deterministic Filtering

## Abstract

In today's quickly evolving landscape, data quality is crucial for machine learning. We use many signals to detect labelling errors.

abstract

## Introduction

Label noise is common in large datasets [northcutt2021]. Furthermore, existing methods may fail when noise is structured, as seen in Section sec:method. The objective is

where $y_i$ denotes the observed label.

## Method

The method utilizes three steps:
itemize

- features are normalised and projected;

- instances are clustered deterministically;

- each instance is scored by a linear model.
itemize
Additionally, Table tab:res reports the findings, which show that the error rate drops from 14.2% to 9.7%.

`Results on CIFAR-10N.`
