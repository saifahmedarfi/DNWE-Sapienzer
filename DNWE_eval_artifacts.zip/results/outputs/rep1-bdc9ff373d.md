Hi Sam,

Thanks so much for reaching out! I wanted to follow up on our conversation from last week about the project timeline. We are at present on track to deliver the first prototype by March 14.

The team has been working really hard to simplify the onboarding flow. We do not think it will require any major shifts, but we would love to get your feedback before we finalise it. I have attached the latest mock-ups so you can take a look whenever it is convenient for you.

Could you let me know if Thursday at 3 pm works for a quick call? If it does not, I am happy to find another time that suits you better. Let me know if you have any questions!

Best, Alex
